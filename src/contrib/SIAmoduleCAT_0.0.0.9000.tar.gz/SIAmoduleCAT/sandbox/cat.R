library(tidyverse)
library(ShinyItemAnalysis)
library(mirt)
library(mirtCAT)


d <- dataMedical[, 1:100] %>% as_tibble()
usethis::use_data(d, overwrite = TRUE)

fit <- mirt(d, itemtype = "2PL", SE = TRUE)
usethis::use_data(fit, overwrite = TRUE)


posthoc_sim <- mirtCAT(
  mo = fit,
  local_pattern = d[2, ],
  start_item = "MI",
  method = "MAP",
  criteria = "MI",
  design = list(min_SEM = 0.25)
)


posthoc_sim %>% summary

posthoc_sim %>% plot
