#' UI part
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
#'
#' @export
#'
main_ui <- function(id) {
  ns <- NS(id)

  tagList(
    h2("CAT module"),
    p("The module uses pre-fitted 2PL model of dataMedical and raw dataMedical dataframe (all packed and provided within the module)."),
    numericInput(ns("resp_num"), "Respondent no.", value = 1),
    sliderInput(ns("min_se"), "Min. SE", value = .25, min = 0, max = 1, step = .01),
    plotOutput(ns("plot"))
  )
}

#' Server part
#'
#' @noRd
#'
#' @importFrom mirtCAT mirtCAT
#' @import shiny
#' @import ggplot2
#'
#' @export
#'
main_server <- function(id, ...) {
  moduleServer(id, function(input, output, session) {
    ns <- session$ns


    # create a reactive component that "listens" for any change of UI inputs or anything reactive
    posthoc_sim <- reactive({
      mirtCAT(
        mo = fit,
        local_pattern = d[input$resp_num, ],
        start_item = "MI",
        method = "MAP",
        criteria = "MI",
        design = list(min_SEM = input$min_se)
      )
    })

    # create output "slot" for the plot - the name is used in UI part to show the actual output
    output$plot <- renderPlot({
      posthoc_sim() %>% plot()
    })
  })
}
