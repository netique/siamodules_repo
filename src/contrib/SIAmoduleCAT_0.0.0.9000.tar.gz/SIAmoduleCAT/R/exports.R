#' d
#'
"d"

#' fit
#'
"fit"
