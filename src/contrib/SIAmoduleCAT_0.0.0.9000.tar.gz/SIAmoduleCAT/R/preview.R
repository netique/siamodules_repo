#' Preview the module
#'
#' @return Shiny app object.
#'
#' @import shiny
#'
#' @export
#'
preview_mod <- function() {


  # This is just the shiny app skeleton to test module's module in

  # define UI part (just call the UI function of the module)
  ui <- fluidPage(
    main_ui("test")
  )

  # define server part (this is a function definition)
  server <- function(input, output, session) {
    main_server("test")
  }

  # run the app using the parts defined above
  shinyApp(ui, server)
}
